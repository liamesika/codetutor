public class DrawLineDemo {
    public static void main(String[] args) {
       // draws a line between (0,0) and (0.5,0.8) 
       StdDraw.line(0.0, 0.0, 0.5, 0.8);
    }
 } 
 