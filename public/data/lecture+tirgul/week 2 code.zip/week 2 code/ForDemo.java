public class ForDemo {
    public static void main(String[] args) {
        for (int count = 0; count < 100; count++) {
            System.out.println("I will not argue ...");
        }
    }
}